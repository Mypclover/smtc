<?php

// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

?>

<!DOCTYPE html>
<html>

<head>
    <?php include('include/head.php'); 
    // Include config file
    require_once "config.php";
    ?>

    <link rel="stylesheet" type="text/css" href="src/plugins/datatables/media/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="src/plugins/datatables/media/css/dataTables.bootstrap4.css">
    <link rel="stylesheet" type="text/css" href="src/plugins/datatables/media/css/responsive.dataTables.css">
    <style>
        <style>table.size {
            table-layout: fixed;
            width: 100%;
        }

        table.size td {

            word-break: break-all;

        }

    </style>
</head>

<body>
    <?php include('include/header.php'); ?>
    <?php include('include/sidebar.php'); ?>
    <div class="main-container">
        <div class="pd-ltr-20 customscroll customscroll-10-p height-100-p xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4>DataTable</h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Table</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
                <!-- Simple Datatable start -->
                <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                    <div class="clearfix mb-20">
                        <div class="pull-left">
                            <h5 class="text-blue"> Table</h5>
                        </div>
                    </div>
                    <div class="row">
                        <table id="searchtable" class="data-table stripe hover size">
                            <thead>
                                <tr>
                                    <th scope="col" class="table-plus datatable-nosort">#</th>
                                    <th scope="col">CUST ID</th>
                                    <th scope="col">Client Name</th>
                                    <th scope="col">REFERRED BY</th>
                                    <th scope="col">IND/CORPORATE</th>
                                    <th scope="col">CORP NAME</th>
                                    <th scope="col">Mobile No</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">PAN</th>
                                    <th scope="col">AADHAR</th>
                                    <th scope="col">DOB</th>
                                    <th scope="col">EQUITY ECC</th>
                                    <th scope="col">TOTAL PRODUCTS</th>
                                    <th scope="col">PRODUCTS</th>
                                    <th scope="col">LINK</th>
                                    <th scope="col" class="datatable-nosort">Action</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                            //$link = mysqli_connect("localhost", "root", "", "smtc");
                                              // Check connection
                                              if ($link->connect_error) {
                                               die("Connection failed: " . $link->connect_error);
                                              } 
                                              $count = 1;
                                              $sql = "SELECT * FROM clients";
                                              $result = $link->query($sql); 
                                            while($row = $result->fetch_assoc()) { ?>

                                <tr>
                                    <td scope="row" class="table-plus"><?php echo $count++ ?></td>
                                    <td scope="row"><?php echo $row['CUST_ID'] ?></td>
                                    <td scope="row"><?php echo $row['Client_Name'] ?></td>
                                    <td scope="row"><?php echo $row['Referred_By'] ?></td>
                                    <td scope="row"><?php echo $row['Ind_Cor'] ?></td>
                                    <td scope="row"><?php echo $row['Cor_name'] ?></td>
                                    <td scope="row"><?php echo $row['Mobile_No'] ?></td>
                                    <td scope="row"><?php echo $row['Email'] ?></td>
                                    <td scope="row"><?php echo $row['Pan'] ?></td>
                                    <td scope="row"><?php echo $row['Aadhaar'] ?></td>
                                    <td scope="row"><?php echo $row['Dob'] ?></td>
                                    <td scope="row"><?php echo $row['Equity'] ?></td>
                                    <td scope="row"><?php echo $row['Total_Products'] ?></td>
                                    <td scope="row"><?php echo $row['Products'] ?></td>

                                    <td scope="row"> <?php echo $row['CUST_ID'].$row['Client_Name'] ?></td>
                                    <td scope="row">
                                        <div class="dropdown">
                                            <a class="btn btn-outline-primary dropdown-toggle" href="#" role="button" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-h"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="edit.php?edit=<?php echo $row['CUST_ID']; ?>"><i class="fa fa-pencil"></i> Edit</a>
                                                <a class='dropdown-item' onClick="return confirm('Are you sure to delete this user?');" href="delete.php?remove=<?php echo $row['CUST_ID']; ?> "><i class='fa fa-trash'></i> Delete</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>

                                <?php }$link->close();
                            ?>

                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- Simple Datatable End -->

                <?php 
                
                 if(isset($_POST['delete']))
                        {
                        // = mysqli_connect('localhost','root', '','smtc');
                            $id=$_GET['edit'];
                            $query="DELETE FROM clients WHERE CUST_ID='$id'";
                            $update=mysqli_query($link,$query);
                            echo "<script>window.open('table.php ','_self')</script>";
                        }
                ?>

            </div>
            <?php include('include/footer.php'); ?>
        </div>
    </div>
    <?php include('include/script.php'); ?>
    <script src="src/plugins/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="src/plugins/datatables/media/js/dataTables.bootstrap4.js"></script>
    <script src="src/plugins/datatables/media/js/dataTables.responsive.js"></script>
    <script src="src/plugins/datatables/media/js/responsive.bootstrap4.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.colVis.min.js"></script>
    <!-- buttons for Export datatable -->
    <script src="src/plugins/datatables/media/js/button/dataTables.buttons.js"></script>
    <script src="src/plugins/datatables/media/js/button/buttons.bootstrap4.js"></script>
    <script src="src/plugins/datatables/media/js/button/buttons.print.js"></script>
    <script src="src/plugins/datatables/media/js/button/buttons.html5.js"></script>
    <script src="src/plugins/datatables/media/js/button/buttons.flash.js"></script>
    <script src="src/plugins/datatables/media/js/button/pdfmake.min.js"></script>
    <script src="src/plugins/datatables/media/js/button/vfs_fonts.js"></script>
    <script>
        $('document').ready(function() {
            $('.data-table').DataTable({

                dom: 'Bfrtip',
                buttons: [
                    {
                        extend: 'colvisGroup',
                        text: 'RefBy',
                        show: [1, 2],
                        hide: [3,4]
                    },
                    {
                        extend: 'colvisGroup',
                        text: 'Email/PAN/Aadhaar',
                        show: [3, 4, 5],
                        hide: [7, 8,9]
                    },
                    {
                        extend: 'colvisGroup',
                        text: 'Equity Ecc/Total Products',
                        show: [3, 4, 5],
                        hide: [11, 12]
                    },
                    {
                        extend: 'colvisGroup',
                        text: 'Show all',
                        show: ':hidden'
                    }
                ],

                scrollCollapse: true,
                autoWidth: false,
                responsive: true,
                columnDefs: [{
                    targets: "datatable-nosort",
                    orderable: false,
                }],
                "lengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                "language": {
                    "info": "_START_-_END_ of _TOTAL_ entries",
                    searchPlaceholder: "Search"
                },
            });
            $('.data-table-export').DataTable({
                scrollCollapse: true,
                autoWidth: false,
                responsive: true,
                columnDefs: [{
                    targets: "datatable-nosort",
                    orderable: false,
                }],
                "lengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                "language": {
                    "info": "_START_-_END_ of _TOTAL_ entries",
                    searchPlaceholder: "Search"
                },
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'pdf', 'print'
                ]
            });
            var table = $('.select-row').DataTable();
            $('.select-row tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    table.$('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });
            var multipletable = $('.multiple-select-row').DataTable();
            $('.multiple-select-row tbody').on('click', 'tr', function() {
                $(this).toggleClass('selected');
            });


        });

    </script>

</body>

</html>
