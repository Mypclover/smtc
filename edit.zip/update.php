<?php
$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server
$db = mysql_select_db("smtc", $connection); // Selecting Database from Server
if(isset($_POST['update'])){ // Fetching variables of the form which travels in URL
    //$id=$_GET['edit'];
    $custid = $_POST['custid'];
    $clientname = $_POST['clientname'];
    $nickname = $_POST['nickname'];
    $refferedby = $_POST['refferedby'];
    $Ind_Cor = $_POST['Ind_Cor'];
    $Cor_name = $_POST['Cor_name'];
    $mobileno = $_POST['mobileno'];
    $email = $_POST['email'];
    $pan = $_POST['pan'];
    $aadhaar = $_POST['aadhaar'];
    $dob = $_POST['dob'];
    $Equity = $_POST['Equity'];
    $Total_Products = $_POST['Total_Products'];
    $products = $_POST['products'];
    $link = $_POST['link'];
    
if($custid !=''||$email !=''){
//Update Query of SQL
$query = mysql_query("update clients set Aadhaar='$aadhar', Client_Name ='$clientname', Cor_name='$Cor_name', Dob ='$dob', Email='$email', Equity='$Equity', Ind_Cor='$Ind_Cor', Link='$link', Mobile_No='$mobileno', Nick_Name='$nickname', Pan='$pan', Products='$products', Referred_By='$refferedby', Total_Products='$Total_Products' WHERE CUST_ID='$cusid'");
echo "<br/><br/><span>Data Inserted successfully...!!</span>";
    
     header("Location: table.php");
    
}
else{
echo "<p>Insertion Failed <br/> Some Fields are Blank....!!</p>";
}
}
mysql_close($connection); // Closing Connection with Server
?>
