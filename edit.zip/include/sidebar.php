	<div class="left-side-bar">
		<div class="brand-logo">
			<a href="index.php">
				<img src="vendors/images/deskapp-logo.png" alt="">
			</a>
		</div>
		<div class="menu-block customscroll">
			<div class="sidebar-menu">
				<ul id="accordion-menu">
					<li>
						<a href="index.php" class="dropdown-toggle no-arrow">
							<span class="fa fa-home"></span><span class="mtext">Home</span>
						</a>
					</li>
                    <li>
						<a href="table.php" class="dropdown-toggle no-arrow">
							<span class="fa fa-table"></span><span class="mtext">Table</span>
						</a>
					</li>
                    <li>
						<a href="reports.php" class="dropdown-toggle no-arrow">
							<span class="fa fa-vcard"></span><span class="mtext">Reports</span>
						</a>
					</li>
                    <li>
						<a href="customer.php" class="dropdown-toggle no-arrow">
							<span class="fa fa-pencil-square-o"></span><span class="mtext">Add Customer</span>
						</a>
					</li>
                    <li>
						<a href="import.php" class="dropdown-toggle no-arrow">
							<span class="fa fa-file-excel-o"></span><span class="mtext">Import Data</span>
						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>