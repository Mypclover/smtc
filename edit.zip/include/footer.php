	<div class="footer-wrap bg-white pd-20 mb-20 border-radius-5 box-shadow">
		 <p><?php echo date("Y"); ?> © Admin Panel. - <a href="#">smtc.com</a></p>
	</div>