<?php
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
$conn = mysqli_connect("localhost","root","","smtc");
require_once('vendors/php-excel-reader/excel_reader2.php');
require_once('vendors/SpreadsheetReader.php');

if (isset($_POST["import"]))
{
    
    
  $allowedFileType = ['application/vnd.ms-excel','text/xls','text/xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
  
  if(in_array($_FILES["file"]["type"],$allowedFileType)){

        $targetPath = 'uploads/'.$_FILES['file']['name'];
        move_uploaded_file($_FILES['file']['tmp_name'], $targetPath);
        
        $Reader = new SpreadsheetReader($targetPath);
        
        $sheetCount = count($Reader->sheets());
        for($i=0;$i<$sheetCount;$i++)
        {
            
            $Reader->ChangeSheet($i);
            $var =0;
            foreach ($Reader as $Row)
            {
                if($var>0){
                $custid = "";
                if(isset($Row[0])) {
                    $custid = mysqli_real_escape_string($conn,$Row[0]);
                }
                
                $clientname = "";
                if(isset($Row[1])) {
                    $clientname = mysqli_real_escape_string($conn,$Row[1]);
                }
                
                $nickname = "";
                if(isset($Row[2])) {
                    $nickname = mysqli_real_escape_string($conn,$Row[2]);
                }
                
                $refferedby = "";
                if(isset($Row[3])) {
                    $refferedby = mysqli_real_escape_string($conn,$Row[3]);
                }
                
                $indcor = "";
                if(isset($Row[4])) {
                    $indcor = mysqli_real_escape_string($conn,$Row[4]);
                }
                
                $corname = "";
                if(isset($Row[5])) {
                    $corname = mysqli_real_escape_string($conn,$Row[5]);
                }
                
                $mobileno = "";
                if(isset($Row[6])) {
                    $mobileno = mysqli_real_escape_string($conn,$Row[6]);
                }
                
                $email = "";
                if(isset($Row[7])) {
                    $email = mysqli_real_escape_string($conn,$Row[7]);
                }
                
                $pan = "";
                if(isset($Row[8])) {
                    $pan = mysqli_real_escape_string($conn,$Row[8]);
                }
                
                $aadhaar = "";
                if(isset($Row[9])) {
                    $aadhaar = mysqli_real_escape_string($conn,$Row[9]);
                }
                
                $dob = "";
                if(isset($Row[10])) {
                    $dob = mysqli_real_escape_string($conn,$Row[10]);
                }
                
                $equity = "";
                if(isset($Row[11])) {
                    $equity = mysqli_real_escape_string($conn,$Row[11]);
                }
                
                $totalproducts = "";
                if(isset($Row[12])) {
                    $totalproducts = mysqli_real_escape_string($conn,$Row[12]);
                }
                
                $products = "";
                if(isset($Row[13])) {
                    $products = mysqli_real_escape_string($conn,$Row[13]);
                }
                
                $link = "";
                if(isset($Row[14])) {
                    $link = mysqli_real_escape_string($conn,$Row[14]);
                }
                
                
                if (!empty($cusid) || !empty($clientname)) {
                      echo '<script type="text/javascript">alert("' . $custid . '")</script>';
                    $query = " insert into clients (Products, Equity, Total_Products, Aadhaar, Pan, Cor_name, Client_Name, CUST_ID, Nick_Name, Referred_By, Mobile_No, Ind_Cor, Email, Link, Dob) VALUES ('".$products."','".$equity."','".$totalproducts."','".$aadhaar."','".$pan."','".$corname."','".$clientname."','".$custid."','".$nickname."','".$refferedby."','".$mobileno."','".$indcor."','".$email."','".$link."','".$dob."') ";
                    $result = mysqli_query($conn, $query);
                
                    if (! empty($result)) {
                        $type = "success";
                        $message = "Excel Data Imported into the Database";
                    } else {
                        $type = "error";
                        $message = "Problem in Importing Excel Data";
                    }
                }
                }
                $var++;
             }
        
         }
  }
  else
  { 
        $type = "error";
        $message = "Invalid File Type. Upload Excel File.";
  }
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include('include/head.php'); ?>
    <style>
    .center-block {
            display: table;
            margin-left: auto;
            margin-right: auto;
            padding-top: 125px;
            padding-bottom: 125px;
        }
    
    </style>
</head>
<body>
	<?php include('include/header.php'); ?>
	<?php include('include/sidebar.php'); ?>
	<div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Import Data</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Import Data</li>
								</ol>
							</nav>
						</div>
						
					</div>
				</div>
				<div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                    <h3>Upload Excel File </h3>
                 <div class="center-block">
                        <form action="" method="post"
                            name="frmExcelImport" id="frmExcelImport" enctype="multipart/form-data">
                            <div>
                                <label>Choose Excel
                                    File</label> <input type="file" name="file"
                                    id="file" accept=".xls,.xlsx">
                                <button type="submit" id="submit" name="import"
                                    class="btn btn-success">Import</button>

                            </div>

                        </form>

                    </div>
                    
                    <div class="<?php if(!empty($type)) { echo $type . " alert alert-success"; } ?>" id="response" role="alert"><?php if(!empty($message)) { echo $message; } ?></div>
         
                    <div class="container ">
                       <p>Download Excel Template </p> <button class="btn btn-info"> <a href="download/clients.xlsx">Here</a></button>
                    
                    </div>
				</div>
			</div>
			<?php include('include/footer.php'); ?>
		</div>
	</div>
	<?php include('include/script.php'); ?>
</body>
</html>