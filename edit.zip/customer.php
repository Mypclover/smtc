<?php
// Initialize the session
session_start();
 // Include config file
require_once "config.php";
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include('include/head.php'); ?>
</head>
<body>
	<?php include('include/header.php'); ?>
	<?php include('include/sidebar.php'); ?>
	<div class="main-container">
		<div class="pd-ltr-20 customscroll customscroll-10-p height-100-p xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Customer Details</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Add Customer</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>
				<!-- Form grid Start -->
				<div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
					<div class="clearfix">
						<div class="pull-left">
							<h4 class="text-blue">Add New Customer</h4>
							<p class="mb-30 font-14">Enter the Customer Details</p>
						</div>
					</div>
				 <form method="post" action="process.php">
						<div class="row">
							<div class="col-md-3 col-sm-12">
								<div class="form-group">
									<label>Customer ID</label>
									<input type="text" class="form-control" name="custid">
								</div>
							</div>
							<div class="col-md-4 col-sm-12">
								<div class="form-group">
									<label>Client Name</label>
									<input type="text" class="form-control" name="clientname">
								</div>
							</div>
							<div class="col-md-4 col-sm-12">
								<div class="form-group">
									<label>Nick Name</label>
									<input type="text" class="form-control" name="nickname">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-4 col-sm-12">
								<div class="form-group">
									<label>Referred By</label>
									<input type="text" class="form-control"  name="refferedby">
								</div>
							</div>
							<div class="col-md-3 col-sm-12">
								<div class="form-group">
									<label>IND/Corporate</label>
									<select class="custom-select2 form-control" name="Ind_Cor" style="width: 100%; height: 38px;">
										<optgroup label="Select Any">
											<option>IND</option>
											<option>Corporate</option>
										</optgroup>
									</select>
								</div>
							</div>
							<div class="col-md-4 col-sm-12">
								<div class="form-group">
									<label>Corporate Name</label>
									<input type="text" class="form-control"  name="Cor_name">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6 col-sm-12">
								<div class="form-group">
									<label>Email ID</label>
									<input class="form-control" type="email"  name="email">
								</div>
							</div>
							<div class="col-md-4 col-sm-12">
								<div class="form-group">
									<label>Mobile Number</label>
									<input type="number" class="form-control"  name="mobileno">
								</div>
							</div>
							<div class="col-md-6 col-sm-12">
								<div class="form-group">
									<label>PAN Number</label>
									<input type="text" class="form-control" name="pan" pattern="[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}" title="Please Enter valid PAN Number eg:ABCDE1234F ">
								</div>
							</div>
							<div class="col-md-6 col-sm-12">
								<div class="form-group">
									<label>Aadhaar Number</label>
									<input type="text" class="form-control"  name="aadhaar" >
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6 col-sm-12">
								<div class="form-group">
									<label>Date Of Birth</label>
									<input type="text" class="form-control date-picker" name="dob">
								</div>
							</div>
							<div class="col-md-3 col-sm-12">
								<div class="form-group">
									<label>Equity ECC</label>
									<input type="text" class="form-control"  name="Equity">
								</div>
							</div>
							<div class="col-md-3 col-sm-12">
								<div class="form-group">
									<label>Total Products</label>
									<input class="form-control" type="number"  name="Total_Products">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 col-sm-12">
								<div class="form-group">
									<label>Products</label>
									<select class="custom-select2 form-control" multiple="multiple" style="width: 100%;"  name="products[]">
										<optgroup label="Select Products">
										<option>LIC KAMAL</option>
										<option>LIC MYIL</option>
										<option>STAR HEALTH</option>
										<option>NIA HEALTH</option>
										<option>CIGNA TTK</option>
										<option>MAX BUPA</option>
										<option>NIA GENERAL</option>
										<option>BAJAJ</option>
										<option>SRIRAM</option>
										<option>BHARATHI AXA</option>
										<option>MUTUAL FUND</option>
										<option>LIC HFL</option>
										<option>MARRIAGE</option>
										<option>PROPERTY REGD.</option>
										<option>COY REGD.</option>
										<option>PAN CARD</option>
										<option>PASSPORT</option>
										<option>SSI</option>
										<option>SERVICE TAX/ GST</option>
										<option>RTO</option>
										<option>BIRTH CERT</option>
										<option>GAZETTE</option>
										<option>PAPER AD</option>
										<option>ATTESTATION</option>
										<option>LEGAL HEIR</option>
										<option>TRANSCRIPTION</option>
										<option>UNIVERSITY</option>
									</optgroup>
								</select>
							</div>
						</div>
						<div>
							 <button type="submit" name="insert" class="btn btn-success btn  sweet-success" id="sa-close">Submit</button>
						</div>
				</div>
			</form>    
		</div>		
            </div>	</div></div>	
            
			<?php include('include/footer.php'); ?>
			<?php include('include/script.php'); ?>   
</body>
</html>