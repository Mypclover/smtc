


<?php
                        if(isset($_POST['insert']))
                        {
                        $db = mysqli_connect('localhost','root', '','smtc');
                              $products_string = implode(', ', $_POST['products']);
                            $custid = $_POST['custid'];
                            $clientname = $_POST['clientname'];
                            $nickname = $_POST['nickname'];
                            $refferedby = $_POST['refferedby'];
                            $Ind_Cor = $_POST['Ind_Cor'];
                            $Cor_name=$_POST['Cor_name'];
                            $mobileno = $_POST['mobileno'];
                            $email = $_POST['email'];
                            $pan = $_POST['pan'];
                            $aadhaar = $_POST['aadhaar'];
                            $dob = $_POST['dob'];
                            $Equity = $_POST['Equity'];
                            $Total_Products = $_POST['Total_Products'];
                            $products = $_POST['products'];
                            
                            $date = date('Y-m-d',strtotime($dob));
                            
                            echo "<script type='text/javascript'>alert('test');</script>";
                            
//							$link=$_POST['link'];
                            $query = "insert into clients (Products, Equity, Total_Products, Aadhaar, Pan, Cor_name, Client_Name, CUST_ID, Nick_Name, Referred_By, Mobile_No, Ind_Cor, Email, Link, Dob) VALUES ('$products_string', '$Equity', '$Total_Products', '$aadhaar', '$pan', '$Cor_name', '$clientname', '$custid', '$nickname', '$refferedby', '$mobileno', '$Ind_Cor', '$email', '$link', '$date')";
                            $update=mysqli_query($db,$query);
                             header("Location: customer.php");
    
                        }
                       ?>