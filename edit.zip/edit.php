<?php
// Initialize the session
session_start();
// Include config file
require_once "config.php";
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include('include/head.php'); ?>
</head>
<body>
	<?php include('include/header.php'); ?>
	<?php include('include/sidebar.php'); ?>
	<div class="main-container">
		<div class="pd-ltr-20 customscroll customscroll-10-p height-100-p xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>FeedBack Edit Form</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.php">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Edit Form</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>
                
				<div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                

                <form  method="post">
                    <?php
                        if(isset($_GET['edit']))
                        {	$db = mysqli_connect('localhost','root', '','smtc');
                            $id = $_GET['edit'];
                            $sel="select * from clients where CUST_ID='$id'";
                            $kl=mysqli_query($db,$sel);
                            $name=mysqli_fetch_assoc($kl);
                         $productslist = $name['Products'];
                         $pro =  explode(',', $productslist);
                         
                    ?>
                    <div class="row">
                        
							<div class="col-md-3 col-sm-12">
								<div class="form-group">
									<label>Customer ID</label>
									<input type="text" class="form-control" name="custid" value="<?php echo $name['CUST_ID']; ?>" >
								</div>
							</div>
							<div class="col-md-4 col-sm-12">
								<div class="form-group">
									<label>Client Name</label>
									<input type="text" class="form-control" name="clientname" value="<?php echo $name['Client_Name']; ?>">
								</div>
							</div>
							<div class="col-md-4 col-sm-12">
								<div class="form-group">
									<label>Nick Name</label>
									<input type="text" class="form-control" name="nickname" value="<?php echo $name['Nick_Name']; ?>">
								</div>
							</div>
						</div>
                    
						<div class="row">
							<div class="col-md-4 col-sm-12">
								<div class="form-group">
									<label>Referred By</label>
									<input type="text" class="form-control"  name="refferedby" value="<?php echo $name['Referred_By']; ?>">
								</div>
							</div>
							<div class="col-md-3 col-sm-12">
								<div class="form-group">
									<label>IND/Corporate</label>
									<select class="custom-select2 form-control" name="Ind_Cor" style="width: 100%; height: 38px;">
                                        <optgroup label="Select Any">
											<option selected><?php echo $name['Ind_Cor']; ?></option>
											<option>IND</option>
											<option>Corporate</option>
										</optgroup>
									</select>
								</div>
							</div>
							<div class="col-md-4 col-sm-12">
								<div class="form-group">
									<label>Corporate Name</label>
									<input type="text" class="form-control"  name="Cor_name" value="<?php echo $name['Cor_name']; ?>">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6 col-sm-12">
								<div class="form-group">
									<label>Email ID</label>
									<input class="form-control" type="email"  name="email" value="<?php echo $name['Email']; ?>">
								</div>
							</div>
							<div class="col-md-4 col-sm-12">
								<div class="form-group">
									<label>Mobile Number</label>
									<input type="text" class="form-control"  name="mobileno" value="<?php echo $name['Mobile_No']; ?>">
								</div>
							</div>
							<div class="col-md-6 col-sm-12">
								<div class="form-group">
									<label>PAN Number</label>
									<input type="text" class="form-control" name="pan" value="<?php echo $name['Pan']; ?>">
								</div>
							</div>
							<div class="col-md-6 col-sm-12">
								<div class="form-group">
									<label>Aadhaar Number</label>
									<input type="text" class="form-control"  name="aadhaar" value="<?php echo $name['Aadhaar']; ?>">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6 col-sm-12">
								<div class="form-group">
									<label>Date Of Birth</label>
									<input type="text" class="form-control date-picker" name="dob"    value="<?php echo $name['Dob']; ?>">
								</div>
							</div>
							<div class="col-md-3 col-sm-12">
								<div class="form-group">
									<label>Equity ECC</label>
									<input type="text" class="form-control"  name="Equity" value="<?php echo $name['Equity']; ?>">
								</div>
							</div>
							<div class="col-md-3 col-sm-12">
								<div class="form-group">
									<label>Total Products</label>
									<input class="form-control" type="number"  name="Total_Products"  value="<?php echo $name['Total_Products']; ?>">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 col-sm-12">
								<div class="form-group">
									<label>Products</label>
									<select class="custom-select2 form-control" multiple="multiple" style="width: 100%;"  name="products[]">
										<optgroup label="Select Products">
                                        <?php
                                            
                                            foreach ($pro as $item) {
                                            echo "<option selected>".$item."</option>";
                                            }                   
                         
                                        ?>    
										<option>LIC KAMAL</option>
										<option>LIC MYIL</option>
										<option>STAR HEALTH</option>
										<option>NIA HEALTH</option>
										<option>CIGNA TTK</option>
										<option>MAX BUPA</option>
										<option>NIA GENERAL</option>
										<option>BAJAJ</option>
										<option>SRIRAM</option>
										<option>BHARATHI AXA</option>
										<option>MUTUAL FUND</option>
										<option>LIC HFL</option>
										<option>MARRIAGE</option>
										<option>PROPERTY REGD.</option>
										<option>COY REGD.</option>
										<option>PAN CARD</option>
										<option>PASSPORT</option>
										<option>SSI</option>
										<option>SERVICE TAX/ GST</option>
										<option>RTO</option>
										<option>BIRTH CERT</option>
										<option>GAZETTE</option>
										<option>PAPER AD</option>
										<option>ATTESTATION</option>
										<option>LEGAL HEIR</option>
										<option>TRANSCRIPTION</option>
										<option>UNIVERSITY</option>
									</optgroup>
								</select>
							</div>
						</div>
						<div>
							 <button type="submit" name="update" class="btn btn-success btn  sweet-success" id="sa-close">Submit</button>
						</div>
				</div>
                    <?php	
                     }
                    ?>
                </form>

                    
				</div>
			</div>
            
            <?php
                        if(isset($_POST['update']))
                        {
                            $db = mysqli_connect('localhost','root', '','smtc');
                            $products_string = implode(', ', $_POST['products']);
                            $custid = $_POST['custid'];
                            $clientname = $_POST['clientname'];
                            $nickname = $_POST['nickname'];
                            $refferedby = $_POST['refferedby'];
                            $Ind_Cor = $_POST['Ind_Cor'];
                            $Cor_name = $_POST['Cor_name'];
                            $mobileno = $_POST['mobileno'];
                            $email = $_POST['email'];
                            $pan = $_POST['pan'];
                            $aadhaar = $_POST['aadhaar'];
                            $dob = $_POST['dob'];
                            $Equity = $_POST['Equity'];
                            $Total_Products = $_POST['Total_Products'];
                            $products = $_POST['products'];
                            $link = $_POST['link'];
                            
                            
                            $id=$_GET['edit'];

                            //echo '<script type="text/javascript">alert("' . $clientname . '")</script>';

                            $query="update clients set Aadhaar='".$aadhaar."', Client_Name ='".$clientname."', Cor_name='".$Cor_name."', Dob ='".$dob."', Email='".$email."', Equity='".$Equity."', Ind_Cor='".$Ind_Cor."', Link='".$link."', Mobile_No='".$mobileno."', Nick_Name='".$nickname."', Pan='".$pan."', Products='".$products."', Referred_By='".$refferedby."', Total_Products='".$Total_Products."' where CUST_ID='".$custid."'";
                            $update=mysqli_query($db,$query);
                            echo "<script>window.open('table.php ','_self')</script>";
                        }
                    
                        if(isset($_POST['delete']))
                        {
                        $db = mysqli_connect('localhost','root', '','smtc');
                            $id=$_GET['edit'];
                            $query="DELETE FROM clients WHERE CUST_ID='$id'";
                            $update=mysqli_query($link,$query);
                            echo "<script>window.open('table.php ','_self')</script>";
                        }
                       ?>
			<?php include('include/footer.php'); ?>
		</div>
	</div>
	<?php include('include/script.php'); ?>
</body>
</html>
