<?php
    include_once 'config.php';
    $sql = "DELETE FROM clients WHERE CUST_ID='" . $_GET["remove"] . "'";
    if (mysqli_query($link, $sql)) {
       header("location: table.php");
       exit();
    } else {
        echo "Error deleting record: " . mysqli_error($link);
    }
    mysqli_close($link);
?>